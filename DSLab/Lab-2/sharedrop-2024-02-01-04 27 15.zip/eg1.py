import pandas as pd
import numpy as np

s=pd.Series([3,9,-2,10,5])
print(s.sum())

print(s.min())

print(s.max())
